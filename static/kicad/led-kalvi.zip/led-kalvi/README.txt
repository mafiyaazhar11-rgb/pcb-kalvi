PCB Kalvi practice project: 5V power LED (J1 header, R1 330 ohm 0805, D1 red LED 0805).
Open led-kalvi.kicad_pro in KiCad 7 or newer. KiCad will offer to update the files to its current format: say yes.
Board: 30 x 20 mm, 2 layers, two M3 mounting holes.
